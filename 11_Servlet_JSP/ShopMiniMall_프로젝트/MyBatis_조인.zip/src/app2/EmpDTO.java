package app2;

import org.apache.ibatis.type.Alias;

@Alias("EmpDTO")
public class EmpDTO {

	// emp 테이블의 컬럼명과 일치 권장.
	int empno;
	String ename;
	String job;
	int mgr;
	String hiredate; // 날짜는  연산이 필요없으면 그냥 String  처리
	int sal;
	int commission;
	
	int deptno;
	


	public EmpDTO() {}

	public EmpDTO(int empno, String ename, 
			String job, int mgr, String hiredate, int sal, 
			int commission, int deptno) {
		this.empno = empno;
		this.ename = ename;
		this.job = job;
		this.mgr = mgr;
		this.hiredate = hiredate;
		this.sal = sal;
		this.commission = commission;
		this.deptno = deptno;

	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getMgr() {
		return mgr;
	}

	public void setMgr(int mgr) {
		this.mgr = mgr;
	}

	public String getHiredate() {
		return hiredate;
	}

	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public int getCommission() {
		return commission;
	}

	public void setCommission(int commission) {
		this.commission = commission;
	}

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	

	@Override
	public String toString() {
		return "EmpDTO [empno=" + empno + ", ename=" + ename + ", job=" + job + ", mgr=" + mgr + ", hiredate="
				+ hiredate + ", sal=" + sal + ", commission=" + commission + ", deptno=" + deptno 
				+ "]";
	}

	
	
}
