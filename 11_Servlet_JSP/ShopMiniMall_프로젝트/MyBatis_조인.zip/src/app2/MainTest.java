package app2;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import app1.EmpDTO;

public class MainTest {

	public static void main(String[] args) {

		
		SqlSession session=
				MySqlSessionFactory.getSession();
	
		List<EmpDTO> empDeptJoin = 
				session.selectList("app2.EmpDeptJoinMapper.empDeptJoin");
		System.out.println(empDeptJoin);
	}

}
