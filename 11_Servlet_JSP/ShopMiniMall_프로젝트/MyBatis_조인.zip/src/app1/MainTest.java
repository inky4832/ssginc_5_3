package app1;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

public class MainTest {

	public static void main(String[] args) {

		
		SqlSession session=
				MySqlSessionFactory.getSession();
		
		List<EmpDTO> empList1 = session.selectList("app1.EmpDeptJoinMapper.empList1");
		System.out.println(empList1);
		
		List<EmpDTO> empList2 = session.selectList("app1.EmpDeptJoinMapper.empList2");
		System.out.println(empList2);
		
		List<EmpDTO> empDeptJoin = 
				session.selectList("app1.EmpDeptJoinMapper.empDeptJoin");
		System.out.println(empDeptJoin);
	}

}
