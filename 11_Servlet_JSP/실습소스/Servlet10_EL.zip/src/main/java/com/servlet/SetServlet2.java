package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/SetServlet")
public class SetServlet2 extends HttpServlet {

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("SetServlet.doGet");
	
		// 3가지 scope 에 데이터 저장
		
		//1. request scope에 저장
		request.setAttribute("userid", "홍길동");
		
		//2. session scope에 저장
		HttpSession session = request.getSession();
		session.setAttribute("userid2", "이순신");
		
		//3. application scope에 저장
		ServletContext application = getServletContext();
		application.setAttribute("userid3", "유관순");
	
		
		// jsp 요청위임
		request.getRequestDispatcher("el2.jsp").forward(request, response);
		
	}
}
