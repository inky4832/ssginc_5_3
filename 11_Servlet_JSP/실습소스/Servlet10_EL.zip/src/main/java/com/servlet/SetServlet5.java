package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.User;


@WebServlet("/SetServlet5")
public class SetServlet5 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("SetServlet.doGet");
	
		request.setAttribute("user", new User("홍길동", 20));
		
		List<User> list = 
				 Arrays.asList(new User("홍길동1", 20),
						       new User("홍길동2", 30));
		
		request.setAttribute("userList", list);
		
		// jsp 요청위임
		request.getRequestDispatcher("el5.jsp").forward(request, response);
		
	}
}
