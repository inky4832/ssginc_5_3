package com.servlet;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/main")
public class MainServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet");
		
		//복잡한 로직 처리
		List<String> list = Arrays.asList("홍길동","이순신","유관순");
		
		// scope에 저장.
		//1. request scope에 저장
		request.setAttribute("req_list", list);
		
		
		//2. session scope에 저장
		HttpSession session = request.getSession();
		session.setAttribute("session_list", list);
		
		//3. application scope에 저장
		ServletContext application = getServletContext();
		application.setAttribute("application_list", list);
		
		
		//결과물 응답처리 ==> list.jsp 위임
		//포워드방식이용
		RequestDispatcher dis = request.getRequestDispatcher("list.jsp");
		dis.forward(request, response);
	}
}





