package com.util;

import java.util.List;

public class Util {

	public static List list;
}
