package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/login")
public class MemberServlet extends HttpServlet {

	// ?userid=aaa&passwd=123
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet");
		
		
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		
		System.out.println("userid:" + userid);
		System.out.println("passwd:" + passwd);
	}
}





