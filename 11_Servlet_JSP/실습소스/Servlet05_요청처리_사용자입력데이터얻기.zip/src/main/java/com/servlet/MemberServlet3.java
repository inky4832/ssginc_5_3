package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/member3")
public class MemberServlet3 extends HttpServlet {

	// 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet");
		
		//POST 방식의 한글처리
		request.setCharacterEncoding("utf-8");
		
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		
		//hobby
		String [] hobbies = request.getParameterValues("hobby");
		
		System.out.println("userid:" + userid);
		System.out.println("passwd:" + passwd);
		System.out.println("hobby:" + Arrays.toString(hobbies));
	}
}





