package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// 요청url: http://localhost:8090/app/xxx
@WebServlet("/xxx")
public class MainServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
       throws ServletException, IOException {

List<String> list = Arrays.asList("홍길동","이순신");
		        //응답처리
response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.print("<html>");
				out.print("<head>");		
				out.print("<title>Set</title>");
				out.print("</head>");
				out.print("<body>");
	for(String name: list) {
		out.print("이름:" + name +"<br>");
	}
				out.print("</body>");
				out.print("</html>");
		
		
	}
}





