package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// 요청url: http://localhost:8090/app/xxx
@WebServlet("/xxx")
public class MainServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
       throws ServletException, IOException {

		System.out.println("MainServlet.doGet"); // tomcat의 console 에 출력되.
		//요청처리
		
		//응답처리
	
	
	}
}
