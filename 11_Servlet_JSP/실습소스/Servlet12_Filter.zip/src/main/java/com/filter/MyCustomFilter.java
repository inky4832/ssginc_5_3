package com.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class MyCustomFilter implements Filter {

	@Override
	public void doFilter(ServletRequest request, 
			ServletResponse response, 
			FilterChain chain)
			throws IOException, ServletException {

		// 서블릿 요청전에 실행되는 코드
		System.out.println("MyCustomFilter. 서블릿요청전");
		request.setCharacterEncoding("utf-8");
		
	chain.doFilter(request, response); // Filter 적용후 서블릿으로 요청이 가능
		
		// 서블릿 실행되고 브라우저에 응답되기전에 실행되는 코드
		System.out.println("MyCustomFilter.브라우저응답전");
		
	}
}




