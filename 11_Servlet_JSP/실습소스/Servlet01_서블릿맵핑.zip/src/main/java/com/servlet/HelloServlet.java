package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// 요청url: http://localhost:8090/app/xxx2
@WebServlet("/xxx2")
public class HelloServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
       throws ServletException, IOException {

		System.out.println("HelloServlet.doGet"); // tomcat의 console 에 출력되.
		//요청처리
		
		//응답처리
	
	
	}
}
