package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/SetServlet")
public class SetServlet extends HttpServlet {

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("SetServlet.doGet");
	
		// 3가지 scope 에 데이터 저장
		
		//1. request scope에 저장
		request.setAttribute("request", "홍길동");
		String request_scope = 
				(String)request.getAttribute("request");
		
		
		//2. session scope에 저장
		HttpSession session = request.getSession();
		System.out.println(session.isNew());
		
		session.setAttribute("session", "이순신");
		String session_scope = 
				(String)session.getAttribute("session");
		
		//응답처리
		response.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<head>");		
		out.print("<title>Set</title>");
		out.print("</head>");
		out.print("<body>");
		out.print("request scope:" + request_scope);		
		out.print("session scope:" + session_scope);		
		out.print("</body>");
		out.print("</html>");
	}
}
