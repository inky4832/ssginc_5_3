package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/GetServlet")
public class GetServlet extends HttpServlet {

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("GetServlet.doGet");
	
		// 3가지 scope 에서 데이터 조회
		
		//1. request scope에서 조회
		String request_scope = 
				(String)request.getAttribute("request");
		
		//2. session scope에서 조회
		HttpSession session = request.getSession();
		System.out.println(session.isNew());
		String session_scope = 
				(String)session.getAttribute("session");
		
		
		//응답처리
		response.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<head>");		
		out.print("<title>Get</title>");
		out.print("</head>");
		out.print("<body>");
		out.print("request scope:" + request_scope);
		out.print("session scope:" + session_scope);		
		out.print("</body>");
		out.print("</html>");
	}
}
