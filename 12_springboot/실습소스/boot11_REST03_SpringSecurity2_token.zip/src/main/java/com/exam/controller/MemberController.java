package com.exam.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.dto.Member;
import com.exam.security.JwtTokenResponse;
import com.exam.security.JwtTokenService;
import com.exam.service.MemberService;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
public class MemberController {

    MemberService memberService;
    JwtTokenService jwtTokenService;
	
	public MemberController(MemberService memberService, JwtTokenService jwtTokenService) {
		this.memberService = memberService;
		this.jwtTokenService=jwtTokenService;
	}

	@GetMapping("/hello")
	public String hello() {
		log.debug("logger:{}", "hello");
		return "hello world";
	}
	//회원가입
	@PostMapping(value={"/signup"})
	public ResponseEntity<Member> showSignUpSuccessPage(
			@RequestBody Member member) {
		log.debug("logger:{}", member);
	
		//서비스 연동
				// 비번 암호화 필수
				String encptPw = 
						new BCryptPasswordEncoder().encode(member.getPasswd());
				member.setPasswd(encptPw);
				
				int n = memberService.save(member);
		
		return ResponseEntity.ok(member);
	}
	
	//로그인 처리 + token 생성후 반환
	@PostMapping("/login")
	public ResponseEntity<JwtTokenResponse> login(@RequestBody Map<String, String> map){
		
		String userid = map.get("userid");
		String passwd = map.get("passwd");
		Member mem = memberService.findById(userid);
		UsernamePasswordAuthenticationToken auth=null;
		if(mem!=null && new BCryptPasswordEncoder().matches(passwd, mem.getPasswd())) {
			List<GrantedAuthority> list = new ArrayList<>();
			//ROLE 설정시 사용됨
			list.add(new SimpleGrantedAuthority("USER")); // ADMIN
			
			//암호화된 비번대신에 raw 비번으로 설정
			mem.setPasswd(passwd);
			auth = new UsernamePasswordAuthenticationToken(mem, null, list);
		}
		// auth이용해서 token 생성
		String token = jwtTokenService.generateToken(auth);
		log.info("logger:token-{}", token);
		return ResponseEntity.ok(new JwtTokenResponse(token));
	}
	
	
}














