package com.exam.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.dto.Member;
import com.exam.service.MemberService;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
public class MemberController {

    MemberService memberService;
	
	public MemberController(MemberService memberService) {
		this.memberService = memberService;
	}

	@GetMapping("/hello")
	public String hello() {
		log.debug("logger:{}", "hello");
		return "hello world";
	}
	
	@PostMapping(value={"/signup"})
	public ResponseEntity<Member> showSignUpSuccessPage(
			@RequestBody Member member) {
		log.debug("logger:{}", member);
	
		//서비스 연동
				// 비번 암호화 필수
				String encptPw = 
						new BCryptPasswordEncoder().encode(member.getPasswd());
				member.setPasswd(encptPw);
				
				int n = memberService.save(member);
		
		return ResponseEntity.ok(member);
	}
	
	
	
}
