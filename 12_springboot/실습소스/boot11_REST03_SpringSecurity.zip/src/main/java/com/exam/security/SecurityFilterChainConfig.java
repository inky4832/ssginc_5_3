package com.exam.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityFilterChainConfig {

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
		
		//커스터마이징 처리
		
		//1. 불필요한 인증제거
		http.authorizeRequests()
//		    .antMatchers("/hello").permitAll()
		    .anyRequest()
		    .authenticated();
		
		// html 폼로그인에서 기본인증방식으로 변경
		http.httpBasic(Customizer.withDefaults());
		
		// 세션을 비활성화
		http.sessionManagement()
		    .sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		
		//csrf 비활성화
		http.csrf().disable();

		return http.build();
	}
	
}
