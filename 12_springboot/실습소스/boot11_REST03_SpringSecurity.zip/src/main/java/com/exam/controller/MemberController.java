package com.exam.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.dto.Member;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
public class MemberController {


	@GetMapping("/hello")
	public String hello() {
		log.debug("logger:{}", "hello");
		return "hello world";
	}
	
	@PostMapping(value={"/signup"})
	public ResponseEntity<Member> showSignUpSuccessPage(
			@RequestBody Member member) {
		log.debug("logger:{}", member);
	
		
		return ResponseEntity.ok(member);
	}
	
	
	
}
