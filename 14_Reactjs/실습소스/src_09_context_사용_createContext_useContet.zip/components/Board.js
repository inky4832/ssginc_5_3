
import { useContext } from 'react';
import { UserContext } from '../store/user-context';
function Board() {

    const value = useContext(UserContext);

    return (
      <div className="App">
         이름:{value}
      </div>
    );
  }
  
  export default Board;
  