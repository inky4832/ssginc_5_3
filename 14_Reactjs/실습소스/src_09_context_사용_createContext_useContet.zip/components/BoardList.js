import Board from "./Board";


function BoardList() {
    return (
      <div className="App">
         <Board />
      </div>
    );
  }
  
  export default BoardList;
  