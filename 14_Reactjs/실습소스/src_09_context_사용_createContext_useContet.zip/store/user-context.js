
// user-context.js

import {createContext, useState} from 'react';

export const UserContext = createContext('');