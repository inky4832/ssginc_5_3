import logo from './logo.svg';
import './App.css';

import {useState} from 'react';

function App() {

  const [isEditing, setIsEditing] = useState(true);

  // 이벤트 함수
  function handleEvent(){

      // OLD 방식
      // setIsEditing(!isEditing);
// 
      // NEW 방식
      setIsEditing(isEditing=>!isEditing);
// 
  }

  return (
    <div className="App">
       <h2>논리값 state</h2>
       값:{isEditing?"true":"false"}<br></br>
       <button onClick={handleEvent}>edit</button>
    </div>
  );
}

export default App;
