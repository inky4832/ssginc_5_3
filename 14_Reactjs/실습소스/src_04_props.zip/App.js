import logo from './logo.svg';
import './App.css';


//자식 컴포넌트
function Avatar(props){
  console.log("props:", props)
  var username = props.username;
  var age = props.xxx;
  return(
    <div className="Avatar">
        이름:{username}<br></br>
        나이:{age}<br></br>
        주소:{props.address}<br></br>
    </div>
  );
}

function Avatar2(props){

  //객체분해할당
  const { username, xxx, address } = props;

  return(
    <div className="Avatar2">
        이름:{username}<br></br>
        나이:{xxx}<br></br>
        주소:{address}<br></br>
    </div>
  );
}

function Avatar3({ username, xxx, address }){

  return(
    <div className="Avatar2">
        이름:{username}<br></br>
        나이:{xxx}<br></br>
        주소:{address}<br></br>
    </div>
  );
}

function Avatar4({ username, xxx, address="부산" }){
  console.log(address);
  return(
    <div className="Avatar2">
        이름:{username}<br></br>
        나이:{xxx}<br></br>
        주소:{address}<br></br>
    </div>
  );
}

function Avatar5({ username, age, address="부산" }){
  console.log(address);
  return(
    <div className="Avatar2">
        이름:{username}<br></br>
        나이:{age}<br></br>
        주소:{address}<br></br>
    </div>
  );
}

// 부모 컴포넌트
function App() {

  var username="홍길동";
  var age = 20;
  var address = "서울";

  var person ={username:"이순신", age:20, address:"부산"};
  return (
    <div className="App">
       <h2>App 컴포넌트</h2>
       <Avatar username={username}  xxx={age} address={address}/><br></br>
       <Avatar2 username={username}  xxx={age} address={address}/><br></br>
       <Avatar3 username={username}  xxx={age} address={address}/><br></br>
       <Avatar4 username={username}  xxx={age} /><br></br>
       <Avatar5  {...person} /><br></br>
    </div>
  );
}

export default App;
