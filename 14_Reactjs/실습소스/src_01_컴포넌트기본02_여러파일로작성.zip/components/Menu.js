import './Menu.css'

// 함수 선언식
function Menu(){
    return(
        <div className="Menu">
            <h2>Menu 컴포넌트입니다.</h2>
        </div>
    );
}

export {Menu};

