import {useRef, forwardRef, useImperativeHandle} from 'react';

const Child= forwardRef(  
    
    (props, ref)=> {
    const dialog_x = useRef(null);

    useImperativeHandle(ref, ()=>({modal_open}));


    function modal_open(){
        dialog_x.current.showModal();
    }
    return (
      <div className="Child">
         <h2>Child 컴포넌트</h2>
         <dialog ref={dialog_x}>
         <form method="dialog">
            아이디:<input /><br/>
            비번:<input /><br/>
            <button>close</button>
        </form>
        </dialog>
      </div>
    );
  });

  
  
  export default Child;