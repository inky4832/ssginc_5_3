
import {forwardRef} from 'react';

const Child=forwardRef(  
    (props, ref)=> {
     console.log(props, ref);
    return (
      <div className="Child">
        <h2>Child컴포넌ㅌ</h2>
        mesg:{props.mesg}<br></br>
        아이디:<input  ref={ref}/>
      </div>
     );
  } );
  
  export default Child;