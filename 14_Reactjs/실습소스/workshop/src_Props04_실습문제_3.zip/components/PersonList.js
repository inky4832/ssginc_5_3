

import './PersonList.css'
import Person from "./Person";

function PersonList( { persons }){

    return (
        <div className='PersonList'>
        <table border="1">
            <thead>
                <tr>
                    <th>번호</th>
                    <th>이름</th>
                    <th>나이</th>
                </tr>
            </thead>
            <tbody>
                {
                    persons.map((row, idx) => <Person row={row} idx={idx} key={idx} />)
                }
            </tbody>
        </table >
        </div>
    );
}


export default PersonList;