
import './Person.css'
import React from 'react';


export default function Person({ row, idx }){

    return (
        <tr key={idx} className='person-tr'>
            <td>{idx + 1}</td>
            <td>{row.name}</td>
            <td>{row.age}</td>
        </tr>
    );
}
