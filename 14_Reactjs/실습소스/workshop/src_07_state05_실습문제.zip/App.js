import logo from './logo.svg';
import './App.css';

import {useState} from 'react';

function App() {

  const [num, setNum] = useState(0);
  const [step, setStep] = useState(1);

  function up(){
    setNum(num+step);
  }
  function down(){
    setNum(num-step > 0 ? num-step:0);
  }

  function handleEvent(e){
    setStep(Number.parseInt(e.target.value));
  }

  return (
    <div className="App">
      <h2>State 실습</h2>
      step:
      <select onChange={handleEvent}>
        <option>1</option>
        <option>2</option>
        <option>3</option>
      </select>
      <br></br>
      num:{num}
      <br></br>
      <button onClick={()=>up()}>+</button>
      <button onClick={()=>down()}>-</button>
    </div>
  );
}

export default App;
