
import './PersonList.css'
import React, { Component } from 'react';


function PersonList( { persons }){

    return (
        <div className='PersonList'>
         <table border="1">
            <thead>
                <tr>
                    <th>번호</th>
                    <th>이름</th>
                    <th>나이</th>
                </tr>
            </thead>
            <tbody>
                {
                    persons.map((row, idx) => {
                        return <tr key={idx}>
                            <td>{idx + 1}</td>
                            <td>{row.name}</td>
                            <td>{row.age}</td>
                        </tr>
                    })
                }
            </tbody>
         </table >
        </div>  
    );
}


export default PersonList;