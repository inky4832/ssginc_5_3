import logo from './logo.svg';
import './App.css';
import daum from './assets/daum.png';

function App() {
  return (
    <div className="App">
      <h1>daum 로고</h1>
      <img src={daum} width="100" height="100" />
    </div>
  );
}

export default App;
